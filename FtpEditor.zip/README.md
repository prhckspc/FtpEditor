# FtpEditor 
This little app can edit, json files and can do another little things.
In the README just an example for the use!
